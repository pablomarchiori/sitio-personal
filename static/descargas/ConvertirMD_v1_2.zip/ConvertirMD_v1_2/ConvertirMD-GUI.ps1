﻿#Requires -Version 5.1
param(
    [string]$SelectedFolder,
    [string]$SelectedFile
)
if ([string]::IsNullOrWhiteSpace($SelectedFolder) -eq [string]::IsNullOrWhiteSpace($SelectedFile)) {
    throw 'Indicá una carpeta o un archivo, pero no ambos.'
}

Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing
[System.Windows.Forms.Application]::EnableVisualStyles()

$script:IsSingleFile = -not [string]::IsNullOrWhiteSpace($SelectedFile)
$script:SelectedFile = if ($script:IsSingleFile) { [System.IO.Path]::GetFullPath($SelectedFile) } else { '' }
$script:SelectedFolder = if ($script:IsSingleFile) { [System.IO.Path]::GetDirectoryName($script:SelectedFile) } else { [System.IO.Path]::GetFullPath($SelectedFolder) }
$script:ConfigPath = Join-Path $script:SelectedFolder 'convertir-md.ini'
$script:EnginePath = Join-Path $PSScriptRoot 'convertir_md.py'
$script:PythonPath = Join-Path $PSScriptRoot '.venv\Scripts\pythonw.exe'
$script:Worker = $null
$script:EventFile = $null
$script:ResultFile = $null
$script:EventLineCount = 0
$script:Stage = 'idle'
$script:CurrentDestination = ''
$script:CurrentIndex = ''
$script:CurrentZip = ''
$script:WasStopped = $false

function UI-Font([int]$size = 9, [bool]$bold = $false) {
    $style = if ($bold) { [System.Drawing.FontStyle]::Bold } else { [System.Drawing.FontStyle]::Regular }
    return New-Object System.Drawing.Font('Segoe UI', $size, $style)
}

function New-Label([string]$text, [int]$x, [int]$y, [int]$w, [int]$h = 25, [int]$size = 9, [bool]$bold = $false) {
    $v = New-Object System.Windows.Forms.Label
    $v.Text = $text
    $v.SetBounds($x, $y, $w, $h)
    $v.Font = UI-Font $size $bold
    return $v
}

function New-Button([string]$text, [int]$x, [int]$y, [int]$w, [int]$h = 32) {
    $v = New-Object System.Windows.Forms.Button
    $v.Text = $text
    $v.SetBounds($x, $y, $w, $h)
    $v.Font = UI-Font 9
    return $v
}

function Read-INI([string]$file) {
    $data = @{}
    $section = ''
    if (-not (Test-Path -LiteralPath $file)) { return $data }
    foreach ($line in [System.IO.File]::ReadAllLines($file, [System.Text.Encoding]::UTF8)) {
        $trim = $line.Trim()
        if ($trim -eq '' -or $trim.StartsWith(';') -or $trim.StartsWith('#')) { continue }
        if ($trim -match '^\[([^\]]+)\]$') { $section = $Matches[1].ToLowerInvariant(); continue }
        if ($trim -match '^([^=]+?)\s*=\s*(.*)$') {
            $key = ($section + '.' + $Matches[1].Trim()).ToLowerInvariant()
            $data[$key] = $Matches[2].Trim()
        }
    }
    return $data
}

function Ini-Get($ini, [string]$section, [string]$key, [string]$fallback) {
    $name = ($section + '.' + $key).ToLowerInvariant()
    if ($ini.ContainsKey($name)) { return [string]$ini[$name] }
    return $fallback
}

function Split-Items([string]$items) {
    return @($items -split '[,;\r\n]+' | ForEach-Object { $_.Trim() } | Where-Object { $_ -ne '' })
}

function Show-ConfigWizard([string]$folder) {
    $ini = Read-INI (Join-Path $folder 'convertir-md.ini')
    $script:Wizard = @{}
    $f = New-Object System.Windows.Forms.Form
    $f.Text = 'Configurar conversión a Markdown'
    $f.StartPosition = 'CenterScreen'
    $f.Size = New-Object System.Drawing.Size(780, 660)
    $f.MinimumSize = New-Object System.Drawing.Size(780, 660)
    $f.MaximumSize = New-Object System.Drawing.Size(1000, 760)
    $f.Font = UI-Font 9
    $f.FormBorderStyle = 'Sizable'
    $script:Wizard.Form = $f
    $script:Wizard.Result = 'cancel'
    $f.Controls.Add((New-Label 'Configuración por carpeta: convertir-md.ini' 18 12 730 30 12 $true))
    $tabs = New-Object System.Windows.Forms.TabControl
    $tabs.SetBounds(18, 50, 730, 485)
    $tabs.Anchor = 'Top,Bottom,Left,Right'
    $script:Wizard.Tabs = $tabs
    foreach ($caption in @('1. Ubicación', '2. Formatos y exclusiones', '3. Opciones')) {
        $tab = New-Object System.Windows.Forms.TabPage
        $tab.Text = $caption
        $tab.BackColor = [System.Drawing.Color]::White
        [void]$tabs.TabPages.Add($tab)
    }
    $f.Controls.Add($tabs)

    # TAB 1 - carpetas
    $t0 = $tabs.TabPages[0]
    $t0.Controls.Add((New-Label 'Origen (carpeta sobre la que hiciste clic derecho)' 18 22 670 25 10 $true))
    $origin = New-Object System.Windows.Forms.TextBox
    $origin.SetBounds(18, 50, 665, 26)
    $origin.Text = $folder
    $origin.ReadOnly = $true
    $t0.Controls.Add($origin)
    $t0.Controls.Add((New-Label 'Destino: ruta absoluta o relativa al origen' 18 105 650 25 10 $true))
    $txtDest = New-Object System.Windows.Forms.TextBox
    $txtDest.SetBounds(18, 135, 665, 26)
    $txtDest.Text = Ini-Get $ini 'General' 'destino' ('..\' + (Split-Path -Leaf $folder) + '_md')
    $t0.Controls.Add($txtDest)
    $t0.Controls.Add((New-Label 'Ejemplo: ..\evidencias_md crea una carpeta hermana de evidencias.' 18 170 670 26))
    $t0.Controls.Add((New-Label 'Los originales no se modifican. Se conserva el árbol de subcarpetas.' 18 215 670 26))
    $script:Wizard.Destination = $txtDest

    # TAB 2 - formatos y exclusiones
    $t1 = $tabs.TabPages[1]
    $t1.Controls.Add((New-Label 'Seleccioná qué formatos convertir:' 14 8 320 23 10 $true))
    $formats = New-Object System.Windows.Forms.CheckedListBox
    $formats.CheckOnClick = $true
    $formats.SetBounds(14, 34, 286, 150)
    $configured = Split-Items (Ini-Get $ini 'Formatos' 'extensiones' 'docx,xlsx,xls,pptx,pdf,html,htm,csv,txt')
    $configured = @($configured | ForEach-Object { $_.ToLowerInvariant().TrimStart('.') })
    foreach ($extension in @('docx','xlsx','xls','pptx','pdf','html','htm','csv','txt','odt','xml','json')) {
        [void]$formats.Items.Add($extension, ($configured -contains $extension))
    }
    $t1.Controls.Add($formats)
    $script:Wizard.Formats = $formats
    $copyMd = New-Object System.Windows.Forms.CheckBox
    $copyMd.SetBounds(14, 176, 300, 21)
    $copyMd.Text = 'Copiar archivos .md originales sin convertir'
    $copyMd.Checked = (Ini-Get $ini 'General' 'copiar_md' 'true') -match '^(true|1|si|sí)$'
    $t1.Controls.Add($copyMd)
    $script:Wizard.CopyMd = $copyMd

    $t1.Controls.Add((New-Label 'Carpetas excluidas por nombre (en cualquier nivel):' 320 8 360 25 9 $true))
    $excludeNames = New-Object System.Windows.Forms.TextBox
    $excludeNames.SetBounds(320, 35, 365, 26)
    $excludeNames.Text = Ini-Get $ini 'Exclusiones' 'carpetas' ''
    $t1.Controls.Add($excludeNames)
    $t1.Controls.Add((New-Label 'Ejemplo: exportaciones,fuentes_originales' 320 65 360 23))
    $t1.Controls.Add((New-Label 'Archivos excluidos (comodines):' 320 95 360 25 9 $true))
    $excludeFiles = New-Object System.Windows.Forms.TextBox
    $excludeFiles.SetBounds(320, 120, 365, 26)
    $excludeFiles.Text = Ini-Get $ini 'Exclusiones' 'archivos' '~$*,*.tmp,*.bak'
    $t1.Controls.Add($excludeFiles)
    $script:Wizard.ExcludeNames = $excludeNames
    $script:Wizard.ExcludeFiles = $excludeFiles

    $t1.Controls.Add((New-Label 'Exclusiones por ruta: marcá las carpetas que querés omitir (incluye su contenido).' 14 199 680 24 9 $true))
    $t1.Controls.Add((New-Label 'Subcarpetas disponibles:' 14 222 307 20 9 $true))
    $t1.Controls.Add((New-Label 'Rutas excluidas seleccionadas:' 335 222 350 20 9 $true))
    $tree = New-Object System.Windows.Forms.TreeView
    $tree.CheckBoxes = $true
    $tree.ShowLines = $true
    $tree.ShowPlusMinus = $true
    $tree.SetBounds(14, 245, 310, 178)
    $tree.HideSelection = $false
    $tree.Anchor = 'Top,Bottom,Left'
    $t1.Controls.Add($tree)
    $pathsTxt = New-Object System.Windows.Forms.TextBox
    $pathsTxt.Multiline = $true
    $pathsTxt.ScrollBars = 'Vertical'
    $pathsTxt.SetBounds(335, 245, 350, 178)
    $pathsTxt.Text = (Split-Items (Ini-Get $ini 'Exclusiones' 'rutas' '') | ForEach-Object { $_ -replace '/', '\' }) -join [Environment]::NewLine
    $pathsTxt.Anchor = 'Top,Bottom,Left,Right'
    $t1.Controls.Add($pathsTxt)
    $script:Wizard.Paths = $pathsTxt
    $script:Wizard.Tree = $tree
    $script:Wizard.TreeCap = 400
    $script:Wizard.TreeCount = 0
    $script:Wizard.TreeLoading = $false

    function Add-FolderNodes($parent, [string]$full) {
        if ($script:Wizard.TreeCount -ge $script:Wizard.TreeCap) { return }
        try { $folders = @(Get-ChildItem -LiteralPath $full -Directory -Force -ErrorAction Stop | Sort-Object Name) }
        catch { return }
        foreach ($dir in $folders) {
            if ($script:Wizard.TreeCount -ge $script:Wizard.TreeCap) { break }
            # OneDrive usa ReparsePoint también para carpetas en la nube.
            # Se saltan enlaces/junctions, pero se muestran carpetas normales de OneDrive.
            if ($dir.LinkType -in @('SymbolicLink', 'Junction')) { continue }
            $script:Wizard.TreeCount++
            $relative = $dir.FullName.Substring($folder.TrimEnd('\').Length).TrimStart('\')
            $node = New-Object System.Windows.Forms.TreeNode($dir.Name)
            $node.Tag = $relative
            $auto = @(Split-Items $script:Wizard.ExcludeNames.Text | ForEach-Object { $_.ToLowerInvariant() })
            if ($auto -contains $dir.Name.ToLowerInvariant()) {
                $node.Text = $dir.Name + ' [excluida por nombre]'
                $node.ForeColor = [System.Drawing.Color]::DimGray
            }
            $existing = @(Split-Items $script:Wizard.Paths.Text | ForEach-Object { $_ -replace '/', '\' })
            $node.Checked = $existing -contains $relative
            [void]$parent.Nodes.Add($node)
            # Solo cargamos niveles al expandir, para no recorrer un proyecto enorme.
            [void]$node.Nodes.Add('...')
        }
    }
    $script:Wizard.TreeLoading = $true
    Add-FolderNodes $tree $folder
    $script:Wizard.TreeLoading = $false
    if ($tree.Nodes.Count -eq 0) {
        $empty = New-Object System.Windows.Forms.TreeNode('Esta carpeta no contiene subcarpetas.')
        $empty.ForeColor = [System.Drawing.Color]::DimGray
        $empty.Tag = ''
        [void]$tree.Nodes.Add($empty)
    }
    $tree.add_BeforeExpand({
        param($sender, $ev)
        $node = $ev.Node
        if ($node.Nodes.Count -eq 1 -and $node.Nodes[0].Text -eq '...') {
            $node.Nodes.Clear()
            $script:Wizard.TreeLoading = $true
            Add-FolderNodes $node (Join-Path $folder ([string]$node.Tag))
            $script:Wizard.TreeLoading = $false
        }
    })
    $excludeNames.add_TextChanged({
        $names = @(Split-Items $script:Wizard.ExcludeNames.Text | ForEach-Object { $_.ToLowerInvariant() })
        $stack = New-Object System.Collections.Stack
        foreach ($node in $script:Wizard.Tree.Nodes) { $stack.Push($node) }
        while ($stack.Count -gt 0) {
            $node = $stack.Pop()
            if ($node.Tag -and $node.Text -ne '...') {
                $basename = [System.IO.Path]::GetFileName([string]$node.Tag)
                $autoExcluded = $names -contains $basename.ToLowerInvariant()
                $node.Text = $basename + $(if ($autoExcluded) { ' [excluida por nombre]' } else { '' })
                $node.ForeColor = if ($autoExcluded) { [System.Drawing.Color]::DimGray } else { [System.Drawing.Color]::Black }
            }
            foreach ($child in $node.Nodes) { $stack.Push($child) }
        }
    })
    $tree.add_AfterCheck({
        param($sender, $ev)
        if ($script:Wizard.TreeLoading) { return }
        $rel = [string]$ev.Node.Tag
        if (-not $rel) { return }
        $names = @(Split-Items $script:Wizard.Paths.Text | ForEach-Object { $_ -replace '/', '\' })
        $names = @($names | Where-Object { $_ -ine $rel })
        if ($ev.Node.Checked) { $names += $rel }
        $script:Wizard.Paths.Text = ($names -join [Environment]::NewLine)
    })

    # TAB 3 - opciones
    $t2 = $tabs.TabPages[2]
    $options = @(
        @('Recorrer subcarpetas', 'recursivo', 'true'),
        @('Convertir solo archivos nuevos o modificados', 'solo_modificados', 'true'),
        @('Generar INDICE.md', 'generar_indice', 'true'),
        @('Generar ZIP de Markdown vigentes', 'generar_zip', 'true')
    )
    $script:Wizard.Opts = @{}
    for ($i = 0; $i -lt $options.Count; $i++) {
        $opt = $options[$i]
        $check = New-Object System.Windows.Forms.CheckBox
        $check.SetBounds(18, (18 + 42*$i), 660, 27)
        $check.Text = $opt[0]
        $check.Checked = (Ini-Get $ini 'General' $opt[1] $opt[2]) -match '^(true|1|si|sí)$'
        $t2.Controls.Add($check)
        $script:Wizard.Opts[$opt[1]] = $check
    }
    $strip = New-Object System.Windows.Forms.CheckBox
    $strip.SetBounds(18, 210, 660, 27)
    $strip.Text = 'Sustituir imágenes Base64 por un marcador'
    $strip.Checked = (Ini-Get $ini 'Contenido' 'eliminar_base64' 'true') -match '^(true|1|si|sí)$'
    $t2.Controls.Add($strip)
    $script:Wizard.Strip = $strip
    $t2.Controls.Add((New-Label 'Avisar cuando un Markdown supere (MB):' 18 275 405 25 9 $true))
    $warn = New-Object System.Windows.Forms.NumericUpDown
    $warn.SetBounds(427, 271, 90, 29)
    $warn.Minimum = 0
    $warn.Maximum = 100000
    $warn.DecimalPlaces = 1
    $warn.Increment = [decimal]0.5
    try { $warn.Value = [decimal]::Parse((Ini-Get $ini 'Contenido' 'advertencia_mb' '2').Replace(',', '.'), [System.Globalization.CultureInfo]::InvariantCulture) }
    catch { $warn.Value = 2 }
    $t2.Controls.Add($warn)
    $script:Wizard.Warn = $warn
    $t2.Controls.Add((New-Label '0 desactiva la advertencia. Los archivos grandes no se recortan ni se descartan.' 18 312 660 45))
    $t2.Controls.Add((New-Label 'Para forzar una reconversión completa, desmarcá "solo nuevos o modificados".' 18 360 665 45))

    $btnBack = New-Button 'Anterior' 18 547 95
    $btnNext = New-Button 'Siguiente' 126 547 95
    $btnSave = New-Button 'Guardar configuración' 358 547 180
    $btnSaveRun = New-Button 'Guardar e iniciar' 552 547 195
    $btnBack.Anchor = 'Bottom,Left'; $btnNext.Anchor = 'Bottom,Left'
    $btnSave.Anchor = 'Bottom,Right'; $btnSaveRun.Anchor = 'Bottom,Right'
    foreach ($button in @($btnBack, $btnNext, $btnSave, $btnSaveRun)) { $f.Controls.Add($button) }
    $btnBack.add_Click({ if ($script:Wizard.Tabs.SelectedIndex -gt 0) { $script:Wizard.Tabs.SelectedIndex-- } })
    $btnNext.add_Click({ if ($script:Wizard.Tabs.SelectedIndex -lt 2) { $script:Wizard.Tabs.SelectedIndex++ } })
    $script:Wizard.Back = $btnBack
    $script:Wizard.Next = $btnNext
    $tabs.add_SelectedIndexChanged({
        $script:Wizard.Back.Enabled = ($script:Wizard.Tabs.SelectedIndex -gt 0)
        $script:Wizard.Next.Enabled = ($script:Wizard.Tabs.SelectedIndex -lt 2)
    })
    $btnBack.Enabled = $false
    $saveAction = {
        param($sender, $ev)
        $dest = $script:Wizard.Destination.Text.Trim()
        if ([string]::IsNullOrWhiteSpace($dest)) {
            [void][System.Windows.Forms.MessageBox]::Show('Indicá una carpeta de destino.', 'Configurar Markdown')
            return
        }
        $chosen = @()
        foreach ($item in $script:Wizard.Formats.CheckedItems) { $chosen += [string]$item }
        if ($chosen.Count -eq 0 -and -not $script:Wizard.CopyMd.Checked) {
            [void][System.Windows.Forms.MessageBox]::Show('Seleccioná un formato o activá la copia de archivos .md.', 'Configurar Markdown')
            return
        }
        # Se preserva la forma de lista en un unico valor INI.
        $exclusions = (Split-Items $script:Wizard.Paths.Text | Select-Object -Unique) -join ','
        $iniText = @"
; ConvertirMD 1.2 - configuracion de esta carpeta
; Las rutas relativas se resuelven desde la carpeta que contiene este INI.
[General]
destino = $dest
recursivo = $($script:Wizard.Opts['recursivo'].Checked.ToString().ToLowerInvariant())
solo_modificados = $($script:Wizard.Opts['solo_modificados'].Checked.ToString().ToLowerInvariant())
generar_indice = $($script:Wizard.Opts['generar_indice'].Checked.ToString().ToLowerInvariant())
generar_zip = $($script:Wizard.Opts['generar_zip'].Checked.ToString().ToLowerInvariant())
copiar_md = $($script:Wizard.CopyMd.Checked.ToString().ToLowerInvariant())

[Formatos]
extensiones = $($chosen -join ',')

[Exclusiones]
carpetas = $( (Split-Items $script:Wizard.ExcludeNames.Text) -join ',' )
rutas = $exclusions
archivos = $( (Split-Items $script:Wizard.ExcludeFiles.Text) -join ',' )

[Contenido]
eliminar_base64 = $($script:Wizard.Strip.Checked.ToString().ToLowerInvariant())
advertencia_mb = $($script:Wizard.Warn.Value.ToString([System.Globalization.CultureInfo]::InvariantCulture))
"@
        try {
            $encoding = New-Object System.Text.UTF8Encoding($false)
            [System.IO.File]::WriteAllText((Join-Path $folder 'convertir-md.ini'), $iniText, $encoding)
            $script:Wizard.Result = if ($sender.Text -eq 'Guardar e iniciar') { 'save_start' } else { 'save' }
            $script:Wizard.Form.Close()
        } catch {
            [void][System.Windows.Forms.MessageBox]::Show('No se pudo guardar el INI: ' + $_.Exception.Message, 'Error')
        }
    }
    $btnSave.add_Click($saveAction)
    $btnSaveRun.add_Click($saveAction)
    [void]$f.ShowDialog()
    $outcome = $script:Wizard.Result
    $f.Dispose()
    return $outcome
}

function Quote-Argument([string]$argument) {
    # Windows CommandLineToArgvW: barras invertidas antes de comillas / al final.
    $sb = New-Object System.Text.StringBuilder
    [void]$sb.Append('"')
    $slashes = 0
    foreach ($ch in $argument.ToCharArray()) {
        if ($ch -eq '\') { $slashes++; continue }
        if ($ch -eq '"') {
            [void]$sb.Append(('\' * ($slashes * 2 + 1)))
            [void]$sb.Append('"')
            $slashes = 0
            continue
        }
        if ($slashes -gt 0) { [void]$sb.Append(('\' * $slashes)); $slashes = 0 }
        [void]$sb.Append($ch)
    }
    if ($slashes -gt 0) { [void]$sb.Append(('\' * ($slashes * 2))) }
    [void]$sb.Append('"')
    return $sb.ToString()
}

function Start-Worker([string]$operation) {
    if (-not (Test-Path -LiteralPath $script:PythonPath)) {
        throw 'No se encontró Python en el entorno de ConvertirMD. Ejecutá nuevamente Instalar.ps1.'
    }
    $prefix = Join-Path ([System.IO.Path]::GetTempPath()) ('ConvertirMD_' + [guid]::NewGuid().ToString('N'))
    $script:ResultFile = $prefix + '.json'
    $script:EventFile = $prefix + '.jsonl'
    $script:EventLineCount = 0
    $args = @($script:EnginePath, $operation, $script:SelectedFolder, '--result', $script:ResultFile, '--events', $script:EventFile)
    if ($script:IsSingleFile) { $args += @('--single-file', $script:SelectedFile) }
    $psi = New-Object System.Diagnostics.ProcessStartInfo
    $psi.FileName = $script:PythonPath
    $psi.Arguments = (($args | ForEach-Object { Quote-Argument $_ }) -join ' ')
    $psi.WorkingDirectory = $PSScriptRoot
    $psi.UseShellExecute = $false
    $psi.CreateNoWindow = $true
    $p = New-Object System.Diagnostics.Process
    $p.StartInfo = $psi
    if (-not $p.Start()) { throw 'No se pudo iniciar el motor de conversión.' }
    $script:Worker = $p
    $script:Stage = $operation
    $script:Timer.Start()
}

function Append-Log([string]$line) {
    $stamp = (Get-Date).ToString('HH:mm:ss')
    $script:Log.AppendText(('[{0}] {1}' -f $stamp, $line) + [Environment]::NewLine)
    $script:Log.SelectionStart = $script:Log.TextLength
    $script:Log.ScrollToCaret()
}

function Handle-Event($evt) {
    switch ($evt.kind) {
        'plan' {
            $script:CurrentDestination = [string]$evt.destination
            $script:CurrentZip = [string]$evt.zip
            $script:CurrentIndex = Join-Path $script:CurrentDestination 'INDICE.md'
            $excludedNames = @($evt.excluded_directories).Count
            $script:Details.Text = ('Documentos incluidos: {0}  |  Nuevos: {1}  |  Modificados: {2}  |  Sin cambios: {3}  |  Carpetas excluidas: {4}' -f $evt.files, $evt.counts.new, $evt.counts.changed, $evt.counts.unchanged, $excludedNames)
            $script:DestLabel.Text = 'Destino: ' + $(if ($script:IsSingleFile) { [string]$evt.output } else { [string]$evt.destination })
            $script:DestLabel.AutoEllipsis = $true
            Append-Log ('Plan preparado: {0} documentos, {1} pendientes.' -f $evt.files, $evt.pending)
            if ($evt.excluded_directories) { Append-Log ('Excluidas: ' + (@($evt.excluded_directories) -join ', ')) }
            $script:RunButton.Enabled = ($evt.files -gt 0)
        }
        'start' {
            $script:Progress.Maximum = [Math]::Max(1, [int]$evt.files)
            $script:Progress.Value = 0
            Append-Log ('Conversión iniciada: ' + $evt.files + ' documentos.')
        }
        'current' {
            $script:Status.Text = $(if ($evt.method -eq 'copy') { 'Copiando: ' } else { 'Convirtiendo: ' }) + $evt.source
        }
        'file' {
            $script:Progress.Value = [Math]::Min([int]$evt.current, $script:Progress.Maximum)
            $status = switch ($evt.status) { 'ok' { 'OK' }; 'copied' { 'COPIADO' }; 'error' { 'ERROR' }; default { 'Sin cambios' } }
            $line = $status + ' - ' + $evt.source
            if ($evt.error) { $line += ' (' + $evt.error + ')' }
            if ($evt.removed_images -gt 0) { $line += ' (imágenes Base64 omitidas: ' + $evt.removed_images + ')' }
            Append-Log $line
        }
        'done' {
            $script:CurrentDestination = [string]$evt.destination
            $script:CurrentZip = [string]$evt.zip
            $script:CurrentIndex = Join-Path $script:CurrentDestination 'INDICE.md'
            if ($script:IsSingleFile -and $evt.output) { $script:DestLabel.Text = 'Archivo generado: ' + $evt.output }
            $c = $evt.counts
            $script:Details.Text = ('Nuevos: {0}  |  Actualizados: {1}  |  Sin cambios: {2}  |  Advertencias: {3}  |  Errores: {4}' -f $c.new, $c.updated, $c.unchanged, $c.warnings, $c.errors)
            foreach ($warning in @($evt.warnings)) { if ($warning) { Append-Log ('ADVERTENCIA - ' + $warning) } }
            if ($evt.zip) { Append-Log ('ZIP generado: ' + $evt.zip) }
            $script:Status.Text = if ($c.errors -gt 0) { 'Finalizado con errores. Revisá el índice.' } else { 'Finalizado correctamente.' }
            $script:OpenButton.Enabled = $true
            $script:IndexButton.Enabled = (-not $script:IsSingleFile) -and (Test-Path -LiteralPath $script:CurrentIndex)
        }
        'fatal' {
            Append-Log ('ERROR: ' + $evt.error)
            $script:Status.Text = 'Error: no se pudo completar la operación.'
        }
    }
}

function Poll-Events {
    if (-not $script:EventFile) { return }
    try {
        if (Test-Path -LiteralPath $script:EventFile) {
            # Lectura compatible con escritura simultánea (FileShare.ReadWrite).
            # Solo procesar líneas terminadas en salto de línea; no consumir fragmentos.
            $stream = [System.IO.File]::Open($script:EventFile, [System.IO.FileMode]::Open, [System.IO.FileAccess]::Read, ([System.IO.FileShare]::ReadWrite -bor [System.IO.FileShare]::Delete))
            try {
                $reader = [System.IO.StreamReader]::new($stream, [System.Text.Encoding]::UTF8)
                $all = $reader.ReadToEnd()
            } finally { if ($reader) { $reader.Dispose() } else { $stream.Dispose() } }
            $parts = @($all -split "`n")
            $lines = @()
            if ($parts.Count -gt 1) { $lines = @($parts[0..($parts.Count - 2)]) }
            for ($i = $script:EventLineCount; $i -lt $lines.Count; $i++) {
                try { Handle-Event ($lines[$i] | ConvertFrom-Json -ErrorAction Stop) }
                catch { Append-Log ('Aviso: evento no interpretable (' + $_.Exception.Message + ')') }
            }
            $script:EventLineCount = $lines.Count
        }
        if ($script:Worker -and $script:Worker.HasExited) {
            $script:Timer.Stop()
            Poll-Finish
        }
    } catch {
        $script:Timer.Stop()
        $script:Status.Text = 'Error al supervisar el proceso: ' + $_.Exception.Message
    }
}

function Poll-Finish {
    $stage = $script:Stage
    $script:Stage = 'idle'
    $script:StopButton.Enabled = $false
    $script:ConfigButton.Enabled = -not $script:IsSingleFile
    if ($script:WasStopped) {
        Append-Log 'Interrumpido por el usuario. Las conversiones ya terminadas permanecen en destino.'
        $script:Status.Text = 'Proceso detenido. El índice y el ZIP pueden ser de una ejecución anterior.'
        $script:WasStopped = $false
        $script:RunButton.Enabled = $false
        $script:RefreshButton.Enabled = $true
        return
    }
    if (-not (Test-Path -LiteralPath $script:ResultFile)) {
        Append-Log 'El proceso terminó sin archivo de resultados.'
        $script:Status.Text = 'Error: no hay resultado del motor.'
    } else {
        try {
            $res = Get-Content -LiteralPath $script:ResultFile -Raw -Encoding UTF8 | ConvertFrom-Json
            if ($res.error) {
                $script:Status.Text = 'Error: ' + $res.error
                Append-Log ('ERROR: ' + $res.error)
            }
        } catch { Append-Log ('No se pudo leer el resultado: ' + $_.Exception.Message) }
    }
    if ($stage -eq 'run') {
        $script:RunButton.Enabled = $false
        $script:RefreshButton.Enabled = $true
        if (-not $script:Status.Text.StartsWith('Error')) { Append-Log 'Proceso finalizado. Podés revisar el resultado o actualizar el análisis.' }
    } else {
        $script:RefreshButton.Enabled = $true
        if (-not $script:Status.Text.StartsWith('Error')) { $script:Status.Text = 'Plan listo. Revisá las opciones antes de iniciar.' }
    }
    if ($script:Worker) { $script:Worker.Dispose(); $script:Worker = $null }
    if ($stage -eq 'plan' -and $script:RunAfterPlan -and $script:RunButton.Enabled) {
        $script:RunAfterPlan = $false
        $script:RunButton.PerformClick()
    }
}

function Start-Analysis {
    if ($script:Stage -ne 'idle') { return }
    $script:Status.Text = 'Analizando archivos y comprobando cambios...'
    $script:Details.Text = 'Calculando hashes e identificando exclusiones.'
    $script:RunButton.Enabled = $false
    $script:RefreshButton.Enabled = $false
    $script:ConfigButton.Enabled = $false
    $script:Progress.Value = 0
    try { Start-Worker 'plan' }
    catch {
        $script:Status.Text = 'Error al analizar.'
        Append-Log $_.Exception.Message
        $script:ConfigButton.Enabled = -not $script:IsSingleFile
        $script:RefreshButton.Enabled = $true
        [void][System.Windows.Forms.MessageBox]::Show($_.Exception.Message, 'ConvertirMD')
    }
}

# Ventana principal
$script:Main = New-Object System.Windows.Forms.Form
$script:Main.Text = $(if ($script:IsSingleFile) { 'Convertir archivo a Markdown - ConvertirMD' } else { 'Convertir carpeta a Markdown - ConvertirMD' })
$script:Main.StartPosition = 'CenterScreen'
$script:Main.Size = New-Object System.Drawing.Size(900, 620)
$script:Main.MinimumSize = New-Object System.Drawing.Size(820, 550)
$script:Main.Font = UI-Font 9
$script:Main.Controls.Add((New-Label $(if ($script:IsSingleFile) { 'Convertir archivo a Markdown' } else { 'Convertir carpeta a Markdown' }) 20 18 790 36 14 $true))
$script:Main.Controls.Add((New-Label ('Origen: ' + $(if ($script:IsSingleFile) { $script:SelectedFile } else { $script:SelectedFolder })) 20 60 835 24 9))
$script:DestLabel = New-Label 'Destino: (pendiente de análisis)' 20 88 835 24 9
$script:Main.Controls.Add($script:DestLabel)
$script:Details = New-Label 'Esperando configuración...' 20 126 835 48 9 $true
$script:Main.Controls.Add($script:Details)
$script:Status = New-Label 'Listo.' 20 187 835 28 10 $true
$script:Main.Controls.Add($script:Status)
$script:Progress = New-Object System.Windows.Forms.ProgressBar
$script:Progress.SetBounds(20, 223, 842, 22)
$script:Progress.Anchor = 'Top,Left,Right'
$script:Main.Controls.Add($script:Progress)
$script:Log = New-Object System.Windows.Forms.TextBox
$script:Log.Multiline = $true
$script:Log.ReadOnly = $true
$script:Log.WordWrap = $false
$script:Log.ScrollBars = 'Both'
$script:Log.Font = New-Object System.Drawing.Font('Consolas', 9)
$script:Log.SetBounds(20, 265, 842, 230)
$script:Log.Anchor = 'Top,Bottom,Left,Right'
$script:Main.Controls.Add($script:Log)
$script:ConfigButton = New-Button 'Editar configuración' 20 520 165
$script:RefreshButton = New-Button 'Analizar de nuevo' 195 520 135
$script:RunButton = New-Button 'Iniciar conversión' 341 520 155
$script:StopButton = New-Button 'Detener' 507 520 90
$script:IndexButton = New-Button 'Ver índice' 605 520 105
$script:OpenButton = New-Button 'Abrir destino' 721 520 139
foreach ($b in @($script:ConfigButton, $script:RefreshButton, $script:RunButton, $script:StopButton, $script:IndexButton, $script:OpenButton)) {
    $b.Anchor = 'Bottom,Left'
    $script:Main.Controls.Add($b)
}
$script:RunButton.Enabled = $false
$script:ConfigButton.Enabled = -not $script:IsSingleFile
$script:StopButton.Enabled = $false
$script:IndexButton.Enabled = $false
$script:OpenButton.Enabled = $false
$script:Timer = New-Object System.Windows.Forms.Timer
$script:Timer.Interval = 350
$script:Timer.add_Tick({ Poll-Events })
$script:ConfigButton.add_Click({
    if ($script:IsSingleFile) { return }
    $outcome = Show-ConfigWizard $script:SelectedFolder
    if ($outcome -ne 'cancel') {
        Append-Log 'Configuración guardada.'
        Start-Analysis
        if ($outcome -eq 'save_start') { $script:RunAfterPlan = $true }
    }
})
$script:RefreshButton.add_Click({ Start-Analysis })
$script:RunButton.add_Click({
    if ($script:Stage -ne 'idle') { return }
    $script:RunButton.Enabled = $false
    $script:RefreshButton.Enabled = $false
    $script:ConfigButton.Enabled = $false
    $script:StopButton.Enabled = $true
    $script:IndexButton.Enabled = $false
    $script:OpenButton.Enabled = $false
    $script:Status.Text = 'Preparando conversión...'
    try { Start-Worker 'run' }
    catch {
        $script:Stage = 'idle'
        $script:StopButton.Enabled = $false
        $script:ConfigButton.Enabled = -not $script:IsSingleFile
        $script:RefreshButton.Enabled = $true
        Append-Log ('ERROR: ' + $_.Exception.Message)
    }
})
$script:StopButton.add_Click({
    if ($script:Stage -eq 'run' -and $script:Worker -and -not $script:Worker.HasExited) {
        $answer = [System.Windows.Forms.MessageBox]::Show('¿Detener la conversión? Los documentos ya terminados se conservarán.', 'Confirmar', [System.Windows.Forms.MessageBoxButtons]::YesNo, [System.Windows.Forms.MessageBoxIcon]::Question)
        if ($answer -eq [System.Windows.Forms.DialogResult]::Yes) {
            $script:WasStopped = $true
            try { $script:Worker.Kill() } catch {}
        }
    }
})
$script:IndexButton.add_Click({
    if ($script:CurrentIndex -and (Test-Path -LiteralPath $script:CurrentIndex)) {
        Start-Process -FilePath 'notepad.exe' -ArgumentList (Quote-Argument $script:CurrentIndex)
    }
})
$script:OpenButton.add_Click({
    if ($script:CurrentDestination -and (Test-Path -LiteralPath $script:CurrentDestination)) {
        Start-Process -FilePath 'explorer.exe' -ArgumentList (Quote-Argument $script:CurrentDestination)
    }
})
$script:Main.add_FormClosing({
    param($sender, $ev)
    if ($script:Worker -and -not $script:Worker.HasExited) {
        $answer = [System.Windows.Forms.MessageBox]::Show('Hay un proceso activo. ¿Querés detenerlo y cerrar?', 'ConvertirMD', [System.Windows.Forms.MessageBoxButtons]::YesNo)
        if ($answer -ne [System.Windows.Forms.DialogResult]::Yes) { $ev.Cancel = $true; return }
        try { $script:Worker.Kill() } catch {}
    }
})
$script:Main.add_Shown({
    if ($script:IsSingleFile) {
        $script:Details.Text = 'Archivo individual: sin INI, sin índice y sin ZIP. Resultado junto al original.'
        Start-Analysis
        return
    }
    if (-not (Test-Path -LiteralPath $script:ConfigPath)) {
        $script:Status.Text = 'No se encontró convertir-md.ini.'
        $script:Details.Text = 'Esta carpeta no tiene configuración. Podés crearla con el asistente.'
        Append-Log 'No se convirtió ningún archivo. Primero hay que crear el INI.'
        $reply = [System.Windows.Forms.MessageBox]::Show(
            'No se encontró convertir-md.ini en esta carpeta.' + [Environment]::NewLine + [Environment]::NewLine +
            '¿Querés crear la configuración con el asistente?', 'Configurar conversión',
            [System.Windows.Forms.MessageBoxButtons]::YesNo, [System.Windows.Forms.MessageBoxIcon]::Information)
        if ($reply -eq [System.Windows.Forms.DialogResult]::Yes) {
            $outcome = Show-ConfigWizard $script:SelectedFolder
            if ($outcome -ne 'cancel') {
                Append-Log 'INI creado en la carpeta de origen.'
                Start-Analysis
                if ($outcome -eq 'save_start') { $script:RunAfterPlan = $true }
            }
        }
    } else { Start-Analysis }
})
# Al solicitar Guardar e iniciar, Poll-Finish lanza la conversión tras el análisis.
$script:RunAfterPlan = $false
[void]$script:Main.ShowDialog()
$script:Timer.Stop()
$script:Timer.Dispose()
$script:Main.Dispose()
