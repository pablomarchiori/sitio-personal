# -*- coding: utf-8 -*-
"""ConvertirMD - motor local de conversion recursiva. Python 3.10+."""
import argparse
import configparser
import fnmatch
import hashlib
import importlib.metadata
import json
import os
from pathlib import Path
import re
import shutil
import sys
import tempfile
import time
from datetime import datetime
from urllib.parse import quote
from zipfile import ZipFile, ZIP_DEFLATED

APP_VERSION = '1.2.0'
INI_FILENAME = 'convertir-md.ini'
STATE_FILENAME = '.conversion-state.json'
INDEX_FILENAME = 'INDICE.md'
SUPPORTED_DEFAULT = 'docx,xlsx,xls,pptx,pdf,html,htm,csv,txt'


def emit(path, kind, **kwargs):
    if not path:
        return
    obj = {'kind': kind, **kwargs}
    # El visor WinForms lee este JSONL mientras Python lo escribe.
    # Windows/antivirus/OneDrive pueden causar bloqueos breves.
    # Una notificación de progreso nunca debe interrumpir la conversión.
    for attempt in range(12):
        try:
            with open(path, 'a', encoding='utf-8') as out:
                out.write(json.dumps(obj, ensure_ascii=False) + '\n')
            return
        except PermissionError:
            if attempt == 11:
                print('Aviso: no se pudo escribir el evento de progreso.', file=sys.stderr)
                return
            time.sleep(0.05 * (attempt + 1))


def write_json_atomic(path, obj):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_name(path.name + '.tmp')
    with open(tmp, 'w', encoding='utf-8', newline='\n') as out:
        json.dump(obj, out, ensure_ascii=False, indent=2)
    os.replace(tmp, path)


def boolval(string):
    v = str(string).strip().lower()
    if v in ('true', '1', 'si', 'sí', 'yes', 'on'):
        return True
    if v in ('false', '0', 'no', 'off'):
        return False
    raise ValueError('Valor booleano no valido: ' + str(string))


def tokens(value):
    return [x.strip() for x in re.split(r'[,;\n]', value) if x.strip()]


def normalize_rel(path):
    return str(path).replace('\\', '/').strip('/').casefold()


def is_inside(path, directory):
    a = os.path.normcase(os.path.abspath(str(path)))
    b = os.path.normcase(os.path.abspath(str(directory)))
    try:
        return os.path.commonpath([a, b]) == b
    except ValueError:
        return False


def load_config(origin):
    origin = Path(origin).resolve()
    if not origin.is_dir():
        raise ValueError('La carpeta de origen no existe: ' + str(origin))
    configfile = origin / INI_FILENAME
    if not configfile.is_file():
        raise FileNotFoundError('Falta ' + str(configfile))
    parser = configparser.ConfigParser(interpolation=None)
    parser.read(configfile, encoding='utf-8-sig')
    def opt(section, name, default):
        return parser.get(section, name, fallback=default)
    dest_text = opt('General', 'destino', '..\\' + origin.name + '_md').strip()
    if not dest_text:
        raise ValueError('El destino del INI esta vacio')
    # Expandimos variables de entorno; rutas relativas respecto del origen.
    dest_text = os.path.expandvars(os.path.expanduser(dest_text)).replace('\\', os.sep)
    destination = Path(dest_text)
    if not destination.is_absolute():
        destination = origin / destination
    destination = destination.resolve()
    if is_inside(destination, origin):
        raise ValueError('El destino debe estar fuera del origen para evitar conversiones recursivas.')
    if is_inside(origin, destination):
        raise ValueError('El origen no puede estar dentro del destino.')
    rawext = tokens(opt('Formatos', 'extensiones', SUPPORTED_DEFAULT))
    extensions = sorted(set(x.lower().lstrip('.') for x in rawext))
    copy_md = boolval(opt('General', 'copiar_md', 'true'))
    if not extensions and not copy_md:
        raise ValueError('No se configuraron formatos a convertir ni Markdown a copiar.')
    mb_text = opt('Contenido', 'advertencia_mb', '2').strip().replace(',', '.')
    try:
        mb = float(mb_text)
    except ValueError:
        raise ValueError('advertencia_mb debe ser numerico')
    if mb < 0:
        raise ValueError('advertencia_mb no puede ser negativo')
    conf = {
        'origin': origin,
        'dest': destination,
        'recursive': boolval(opt('General', 'recursivo', 'true')),
        'incremental': boolval(opt('General', 'solo_modificados', 'true')),
        'index': boolval(opt('General', 'generar_indice', 'true')),
        'zip': boolval(opt('General', 'generar_zip', 'true')),
        'extensions': extensions,
        'copy_md': copy_md,
        'exclude_dirs': [v.casefold() for v in tokens(opt('Exclusiones', 'carpetas', ''))],
        'exclude_paths': [normalize_rel(v) for v in tokens(opt('Exclusiones', 'rutas', ''))],
        'exclude_files': [v.casefold() for v in tokens(opt('Exclusiones', 'archivos', '~$*,*.tmp,*.bak'))],
        'strip_base64': boolval(opt('Contenido', 'eliminar_base64', 'true')),
        'warning_bytes': int(mb * 1024 * 1024),
        'warning_mb': mb,
    }
    return conf


def markitdown_version():
    try:
        return importlib.metadata.version('markitdown')
    except importlib.metadata.PackageNotFoundError:
        return None


def conversion_signature(conf):
    effective = {
        # La lógica de conversion no cambió desde 1.1: evitar reconvertir Office
        # solo por añadir la copia de archivos .md al recorrido.
        'tool_version': '1.1.0',
        'markitdown_version': markitdown_version(),
        'strip_base64': conf['strip_base64'],
        'output_naming': 1,
    }
    raw = json.dumps(effective, sort_keys=True)
    return hashlib.sha256(raw.encode('utf-8')).hexdigest()


def sha256_file(path):
    digest = hashlib.sha256()
    with open(path, 'rb') as src:
        while True:
            data = src.read(1024 * 1024)
            if not data:
                break
            digest.update(data)
    return digest.hexdigest()


def should_exclude_dir(dirname, relpath, conf):
    basename = dirname.casefold()
    rel = normalize_rel(relpath)
    if any(fnmatch.fnmatchcase(basename, mask) for mask in conf['exclude_dirs']):
        return True
    return any(rel == path or rel.startswith(path + '/') for path in conf['exclude_paths'])


def should_exclude_file(name, conf):
    return any(fnmatch.fnmatchcase(name.casefold(), pattern) for pattern in conf['exclude_files'])


def collect_sources(conf):
    origin = conf['origin']
    docs = []
    omitted_dirs = []
    omitted_files = 0
    exts = set(conf['extensions'])
    if conf['copy_md']:
        exts.add('md')
    for base, dirnames, filenames in os.walk(origin, topdown=True, followlinks=False):
        basepath = Path(base)
        if not conf['recursive'] and basepath != origin:
            dirnames[:] = []
            continue
        remaining = []
        for name in sorted(dirnames, key=str.casefold):
            directory = basepath / name
            relative = directory.relative_to(origin)
            if directory.is_symlink() or should_exclude_dir(name, relative, conf):
                omitted_dirs.append(str(relative).replace('\\', '/'))
            else:
                remaining.append(name)
        dirnames[:] = remaining
        for name in sorted(filenames, key=str.casefold):
            file = basepath / name
            if file.is_symlink() or should_exclude_file(name, conf):
                omitted_files += 1
                continue
            if file.suffix.lower().lstrip('.') not in exts:
                continue
            rel = file.relative_to(origin)
            is_md = file.suffix.lower() == '.md'
            # Markdown de origen se copia sin alterar bytes ni nombre original.
            target = rel if is_md else rel.parent / (file.stem + '_' + file.suffix.lstrip('.').lower() + '.md')
            docs.append({'src': file, 'rel': rel.as_posix(), 'outrel': target.as_posix(),
                         'method': 'copy' if is_md else 'convert'})
        if not conf['recursive']:
            dirnames[:] = []
    docs.sort(key=lambda v: v['rel'].casefold())
    # No pisar un Markdown original por coincidir con el nombre generado
    # por otro documento (ejemplo: Informe.docx e Informe_docx.md).
    targets = {}
    for doc in docs:
        key = doc['outrel'].casefold()
        if conf['index'] and key == INDEX_FILENAME.casefold():
            raise ValueError('El archivo de origen ' + doc['rel'] + ' coincide con el '
                             'INDICE.md que genera el programa. Excluilo con el patron '
                             'de archivos o desactivá la generación de índice.')
        if key in targets:
            raise ValueError('Conflicto de nombre de salida entre ' + targets[key]
                             + ' y ' + doc['rel'] + ' -> ' + doc['outrel'])
        targets[key] = doc['rel']
    return docs, omitted_dirs, omitted_files


def load_state(conf):
    statefile = conf['dest'] / STATE_FILENAME
    if not statefile.is_file():
        return {'files': {}}
    try:
        data = json.loads(statefile.read_text(encoding='utf-8-sig'))
        if not isinstance(data.get('files'), dict):
            raise ValueError('files invalido')
        return data
    except (ValueError, OSError, TypeError):
        return {'files': {}}


def build_plan(conf):
    docs, excluded_dirs, excluded_files = collect_sources(conf)
    old = load_state(conf).get('files', {})
    sig = conversion_signature(conf)
    counters = {'new': 0, 'changed': 0, 'unchanged': 0, 'unreadable': 0}
    for doc in docs:
        try:
            digest = sha256_file(doc['src'])
            doc['hash'] = digest
            doc['size'] = doc['src'].stat().st_size
            prev = old.get(doc['rel'], {})
            out = conf['dest'] / Path(doc['outrel'])
            if (conf['incremental'] and isinstance(prev, dict)
                    and prev.get('sha256') == digest
                    and prev.get('signature') == sig
                    and prev.get('outrel') == doc['outrel']
                    and out.is_file()):
                doc['action'] = 'unchanged'
            elif not prev or not out.is_file():
                doc['action'] = 'new'
            else:
                doc['action'] = 'changed'
        except (OSError, PermissionError) as exc:
            doc['action'] = 'unreadable'
            doc['error'] = str(exc)
            doc['hash'] = None
            doc['size'] = 0
        counters[doc['action']] += 1
    all_sizes = sum(x['size'] for x in docs)
    return {
        'docs': docs,
        'excluded_dirs': excluded_dirs,
        'excluded_files': excluded_files,
        'counts': counters,
        'bytes_total': all_sizes,
        'signature': sig,
        'previous': old,
    }


def summary_plan(conf, plan):
    return {
        'origin': str(conf['origin']),
        'destination': str(conf['dest']),
        'zip': str(conf['dest']) + '.zip' if conf['zip'] else '',
        'files': len(plan['docs']),
        'pending': plan['counts']['new'] + plan['counts']['changed'] + plan['counts']['unreadable'],
        'counts': plan['counts'],
        'excluded_directories': plan['excluded_dirs'],
        'excluded_file_count': plan['excluded_files'],
        'bytes_total': plan['bytes_total'],
        'extensions': conf['extensions'],
        'copy_md': conf['copy_md'],
        'warning_mb': conf['warning_mb'],
        'zip_enabled': conf['zip'],
        'index_enabled': conf['index'],
    }


# MarkItDown puede incorporar imagenes como data URI (tambien en atributos HTML).
MD_IMAGE_DATA = re.compile(r'!\[([^\]]*)\]\(\s*data:[^\s)]+(?:\s+[^)]*)?\)', re.IGNORECASE)
HTML_IMG_DATA = re.compile(r'<img\b[^>]*\bsrc\s*=\s*["\']data:[^"\']+["\'][^>]*>', re.IGNORECASE)


def clean_text(text, strip):
    if not strip:
        return text, 0
    replacement = '[Imagen incrustada omitida; consultar el documento original]'
    text, n1 = MD_IMAGE_DATA.subn(replacement, text)
    text, n2 = HTML_IMG_DATA.subn(replacement, text)
    return text, n1 + n2


def convert_one(src, output, conf, converter):
    result = converter.convert_local(str(src))
    text = getattr(result, 'text_content', None)
    if text is None:
        text = getattr(result, 'markdown', None)
    if text is None:
        raise ValueError('MarkItDown no devolvio texto')
    text, removed = clean_text(text, conf['strip_base64'])
    output.parent.mkdir(parents=True, exist_ok=True)
    tmp = output.with_name(output.name + '.tmp')
    try:
        tmp.write_text(text, encoding='utf-8', newline='\n')
        os.replace(tmp, output)
    finally:
        if tmp.exists():
            tmp.unlink()
    return {'removed_images': removed, 'bytes': output.stat().st_size}


def copy_markdown(src, output):
    output.parent.mkdir(parents=True, exist_ok=True)
    tmp = output.with_name(output.name + '.tmp')
    try:
        # Copia binaria: evita cambiar codificación, finales de línea y metadatos.
        shutil.copy2(src, tmp)
        os.replace(tmp, output)
    finally:
        if tmp.exists():
            tmp.unlink()
    return {'removed_images': 0, 'bytes': output.stat().st_size}


def markdown_link(rel):
    return quote(rel.replace('\\', '/'), safe='/._-')


def build_index(conf, entries, errors, excluded_dirs, stale, warnings):
    stamp = datetime.now().astimezone().strftime('%Y-%m-%d %H:%M:%S %z')
    lines = [
        '# Índice de documentos preparados', '',
        f'Generado: {stamp}', '',
        'Este índice corresponde a los documentos incluidos en la última ejecución.',
        'Los originales son la referencia para revisar imágenes, fórmulas o diseños complejos.', '',
        f'- Documentos disponibles: **{len(entries)}**',
        f'- Errores: **{len(errors)}**',
        f'- Advertencias: **{len(warnings)}**',
        f'- Carpetas excluidas: **{len(excluded_dirs)}**', '',
        '## Documentos', '',
    ]
    if not entries:
        lines.append('Ningún documento convertido correctamente.')
    else:
        for entry in sorted(entries, key=lambda e: e['rel'].casefold()):
            desc = entry['rel'].replace('|', '\\|')
            lines.append(f'- [{desc}]({markdown_link(entry["outrel"])})')
    if warnings:
        lines += ['', '## Advertencias', '']
        for item in warnings:
            lines.append('- ' + str(item).replace('\n', ' '))
    if errors:
        lines += ['', '## Errores de conversión', '']
        for item in errors:
            lines.append('- **' + str(item['source']).replace('|', '\\|') + '**: ' + str(item['error']).replace('\n', ' '))
    if excluded_dirs:
        lines += ['', '## Carpetas excluidas', '']
        lines += ['- ' + d for d in sorted(excluded_dirs, key=str.casefold)]
    if stale:
        lines += ['', '## Salidas anteriores fuera del índice', '',
                  'Estos resultados antiguos no se borraron ni se incluirán en el ZIP:','']
        lines += ['- ' + d for d in sorted(stale, key=str.casefold)]
    lines.append('')
    return '\n'.join(lines)


def write_zip(conf, entries):
    dest = conf['dest']
    dest.parent.mkdir(parents=True, exist_ok=True)
    zpath = Path(str(dest) + '.zip')
    temp = Path(str(zpath) + '.tmp')
    try:
        with ZipFile(temp, 'w', ZIP_DEFLATED, compresslevel=6) as archive:
            if conf['index'] and (dest / INDEX_FILENAME).exists():
                archive.write(dest / INDEX_FILENAME, INDEX_FILENAME)
            for entry in sorted(entries, key=lambda v: v['outrel'].casefold()):
                outrel = entry['outrel']
                real = dest / Path(outrel)
                if real.is_file() and is_inside(real, dest):
                    archive.write(real, outrel)
        os.replace(temp, zpath)
    finally:
        if temp.exists():
            temp.unlink()
    return zpath


def run_conversion(conf, plan, event_path, result_path):
    dest = conf['dest']
    dest.mkdir(parents=True, exist_ok=True)
    statefile = dest / STATE_FILENAME
    oldfiles = plan['previous']
    newfiles = {}
    errors = []
    warnings = []
    entries = []
    counts = {'new': 0, 'updated': 0, 'unchanged': 0, 'errors': 0, 'warnings': 0}
    pending = [x for x in plan['docs'] if x['action'] != 'unchanged']
    emit(event_path, 'start', total=len(pending), files=len(plan['docs']))
    converter = None
    for ordinal, doc in enumerate(plan['docs'], 1):
        action = doc['action']
        rel = doc['rel']
        outrel = doc['outrel']
        out = dest / Path(outrel)
        if action == 'unreadable':
            counts['errors'] += 1
            errors.append({'source': rel, 'error': doc.get('error', 'No se pudo leer')})
            emit(event_path, 'file', source=rel, status='error', error=doc.get('error', 'No se pudo leer'), current=ordinal, total=len(plan['docs']))
            continue
        if action == 'unchanged':
            counts['unchanged'] += 1
            newfiles[rel] = oldfiles[rel]
            entries.append(doc)
            emit(event_path, 'file', source=rel, status='unchanged', current=ordinal, total=len(plan['docs']))
            continue
        emit(event_path, 'current', source=rel, method=doc['method'], current=ordinal, total=len(plan['docs']))
        try:
            if doc['method'] == 'copy':
                info = copy_markdown(doc['src'], out)
            else:
                if converter is None:
                    from markitdown import MarkItDown
                    converter = MarkItDown(enable_plugins=False)
                info = convert_one(doc['src'], out, conf, converter)
            state_entry = {
                'sha256': doc['hash'],
                'signature': plan['signature'],
                'outrel': outrel,
                'bytes': info['bytes'],
                'removed_images': info['removed_images'],
            }
            newfiles[rel] = state_entry
            entries.append(doc)
            if action == 'new':
                counts['new'] += 1
            else:
                counts['updated'] += 1
            if conf['warning_bytes'] and info['bytes'] > conf['warning_bytes']:
                warning = f'{rel}: Markdown de {info["bytes"] / (1024*1024):.2f} MB (umbral {conf["warning_mb"]} MB)'
                warnings.append(warning)
            emit(event_path, 'file', source=rel, status='copied' if doc['method'] == 'copy' else 'ok',
                 bytes=info['bytes'], removed_images=info['removed_images'], current=ordinal, total=len(plan['docs']))
        except Exception as exc:
            counts['errors'] += 1
            errors.append({'source': rel, 'error': str(exc)})
            emit(event_path, 'file', source=rel, status='error', error=str(exc), current=ordinal, total=len(plan['docs']))
        # Guardado incremental para que una interrupcion no pierda conversiones exitosas.
        checkpoint = dict(oldfiles)
        checkpoint.update(newfiles)
        write_json_atomic(statefile, {'version': APP_VERSION, 'files': checkpoint})
    counts['warnings'] = len(warnings)
    stale = sorted(set(oldfiles) - set(x['rel'] for x in plan['docs']))
    # Se retiran del registro activo los documentos que fallaron, sin borrar sus archivos anteriores.
    write_json_atomic(statefile, {'version': APP_VERSION, 'files': newfiles})
    if conf['index']:
        text = build_index(conf, entries, errors, plan['excluded_dirs'], stale, warnings)
        tmp = dest / (INDEX_FILENAME + '.tmp')
        tmp.write_text(text, encoding='utf-8', newline='\n')
        os.replace(tmp, dest / INDEX_FILENAME)
    zpath = ''
    zip_error = None
    if conf['zip']:
        try:
            zpath = str(write_zip(conf, entries))
        except Exception as exc:
            zip_error = str(exc)
            counts['errors'] += 1
            errors.append({'source': 'ZIP', 'error': zip_error})
    result = {
        'origin': str(conf['origin']),
        'destination': str(dest),
        'zip': zpath,
        'counts': counts,
        'errors': errors,
        'warnings': warnings,
        'excluded_directories': plan['excluded_dirs'],
        'stale': stale,
        'successful_documents': len(entries),
    }
    write_json_atomic(result_path, result)
    emit(event_path, 'done', **result)
    return 2 if counts['errors'] else 0



def single_file_config(path):
    src = Path(path).resolve()
    if not src.is_file():
        raise FileNotFoundError('El archivo seleccionado no existe: ' + str(src))
    if src.suffix.lower().lstrip('.') not in set(SUPPORTED_DEFAULT.split(',')) | {'odt'}:
        raise ValueError('Formato no admitido para conversión individual: ' + src.suffix)
    return src, {
        'origin': src.parent,
        'dest': src.parent,
        'strip_base64': True,
        'warning_mb': 2,
        'warning_bytes': 2 * 1024 * 1024,
    }


def run_single_file(src, conf, event_path, result_path):
    rel = src.name
    output = src.with_name(src.stem + '_' + src.suffix.lstrip('.').lower() + '.md')
    emit(event_path, 'start', total=1, files=1)
    emit(event_path, 'current', source=rel, current=1, total=1)
    warnings = []
    errors = []
    count = {'new': 0, 'updated': 0, 'unchanged': 0, 'errors': 0, 'warnings': 0}
    try:
        from markitdown import MarkItDown
        info = convert_one(src, output, conf, MarkItDown(enable_plugins=False))
        count['new'] = 1
        if info['bytes'] > conf['warning_bytes']:
            warnings.append(f'{rel}: Markdown de {info["bytes"] / (1024*1024):.2f} MB')
        emit(event_path, 'file', source=rel, status='ok', current=1, total=1,
             bytes=info['bytes'], removed_images=info['removed_images'])
    except Exception as exc:
        count['errors'] = 1
        errors.append({'source': rel, 'error': str(exc)})
        emit(event_path, 'file', source=rel, status='error', current=1, total=1, error=str(exc))
    count['warnings'] = len(warnings)
    result = {'origin': str(src), 'destination': str(src.parent), 'zip': '',
              'counts': count, 'errors': errors, 'warnings': warnings,
              'excluded_directories': [], 'stale': [],
              'successful_documents': count['new'], 'output': str(output)}
    write_json_atomic(result_path, result)
    emit(event_path, 'done', **result)
    return 2 if count['errors'] else 0


def main():
    parser = argparse.ArgumentParser(description='ConvertirMD - conversor recursivo local')
    parser.add_argument('operation', choices=['plan', 'run'])
    parser.add_argument('folder')
    parser.add_argument('--result', required=True, help='Ruta JSON de respuesta')
    parser.add_argument('--events', help='Ruta JSONL de eventos')
    parser.add_argument('--single-file', help='Convertir un archivo individual sin INI ni ZIP')
    args = parser.parse_args()
    try:
        if args.single_file:
            src, single_conf = single_file_config(args.single_file)
            output = src.with_name(src.stem + '_' + src.suffix.lstrip('.').lower() + '.md')
            if args.operation == 'plan':
                summary = {'origin': str(src), 'destination': str(src.parent),
                           'zip': '', 'files': 1, 'pending': 1,
                           'counts': {'new': 1, 'changed': 0, 'unchanged': 0, 'unreadable': 0},
                           'excluded_directories': [], 'excluded_file_count': 0,
                           'bytes_total': src.stat().st_size, 'output': str(output)}
                write_json_atomic(args.result, summary)
                emit(args.events, 'plan', **summary)
                return 0
            return run_single_file(src, single_conf, args.events, args.result)
        conf = load_config(args.folder)
        plan = build_plan(conf)
        if args.operation == 'plan':
            write_json_atomic(args.result, summary_plan(conf, plan))
            emit(args.events, 'plan', **summary_plan(conf, plan))
            return 0
        return run_conversion(conf, plan, args.events, args.result)
    except Exception as exc:
        err = {'error': str(exc), 'type': type(exc).__name__}
        write_json_atomic(args.result, err)
        emit(args.events, 'fatal', **err)
        print(str(exc), file=sys.stderr)
        return 1


if __name__ == '__main__':
    sys.exit(main())
