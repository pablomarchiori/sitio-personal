# ConvertirMD — versión 1.2

Herramienta local para preparar árboles de documentos Office y PDF como Markdown para revisión con una IA. También copia los Markdown originales sin convertirlos de nuevo. El ZIP es solo para transporte: **no reduce los tokens**, y puede ser necesario **descomprimirlo** antes de adjuntar archivos a Claude.

## Instalación (Windows 10/11)

1. Instalá **Python 3.10 a 3.14** si todavía no lo tenés: https://www.python.org/downloads/windows/
2. Extraé el ZIP en una carpeta común. No ejecutes el instalador directamente desde la vista comprimida del ZIP.
3. Abrí **Windows PowerShell** en esa carpeta y ejecutá:

   ```powershell
   powershell -NoProfile -ExecutionPolicy Bypass -File .\Instalar.ps1
   ```

   El instalador crea un entorno virtual en `%LOCALAPPDATA%\ConvertirMD`, instala MarkItDown para DOCX, XLSX, XLS, PPTX y PDF, y agrega la opción al menú contextual **solo para tu usuario**. La instalación necesita internet para descargar Python/paquetes, pero la conversión ordinaria se ejecuta localmente.
4. En el Explorador de Windows 11: clic derecho **sobre una carpeta** → **Mostrar más opciones** → **Convertir carpeta a Markdown**.
5. Si la carpeta no contiene `convertir-md.ini`, el programa explica qué falta y ofrece crearlo con un asistente. Seleccioná destino, formatos, exclusiones y opciones. Podés guardar sin convertir o guardar e iniciar.

Para probarlo sin el menú contextual: `powershell -NoProfile -ExecutionPolicy Bypass -File .\Probar-sin-menu.ps1`.

## Conversión e informe

- Origen: la carpeta en la que hiciste clic.
- El `convertir-md.ini` vive **en la raíz del origen**. Las rutas relativas se resuelven desde esa carpeta.
- Destino por defecto: carpeta hermana `NOMBRE_md`.
- Exclusión por nombre de carpeta (en cualquier profundidad) y por rutas concretas seleccionadas en el asistente.
- Convierte DOCX, XLSX, XLS, PPTX, PDF, HTML, HTM, CSV y TXT. **Copia los archivos `.md` originales sin modificarlos**, respetando su nombre, contenido y ubicación relativa; incluso con INI anteriores a 1.2. La opción «Copiar archivos .md originales sin convertir» del asistente permite desactivar esa copia. Los `.md` copiados participan del registro de cambios, del índice y del ZIP. ODT, JSON o XML pueden seleccionarse en el asistente, pero la calidad y disponibilidad dependen de lo que soporte la versión instalada de MarkItDown. No se garantiza la conversión de formatos adicionales.
- Salida: `Informe.docx` → `Informe_docx.md`; `Informe.pdf` → `Informe_pdf.md`, conservando subcarpetas.
- Convierte o copia solo archivos nuevos o cambiados mediante hash SHA-256, con registro `.conversion-state.json`. Si cambia la versión de MarkItDown o la política de Base64, reprocesa.
- Sustituye imágenes incrustadas **enlaces data URI Base64** por un marcador; **no analiza las imágenes** ni garantiza extraer texto contenido únicamente en imágenes/escaneados.
- Genera `INDICE.md` con rutas, advertencias, exclusiones y errores; señala `.md` mayores al umbral indicado.
- Genera `NOMBRE_md.zip` fuera de la carpeta de destino, incluyendo solo Markdown vigentes y el índice. No incluye originales ni archivos internos del conversor.
- Si el documento original se elimina, la salida anterior **no se borra automáticamente**, pero se excluye del índice y del ZIP posterior.
- Si se interrumpe durante la conversión, los Markdown completados quedan. Repetí el análisis y la conversión para generar un ZIP e índice consistentes.
- **Los originales nunca se modifican**. Si modificaste manualmente los `.md` generados o copiados en destino, se pueden sobrescribir en una nueva ejecución. Los originales permanecen intactos.

Para actualizar una instalación existente sin reinstalar las dependencias, ejecutá `Actualizar.ps1` desde la carpeta del paquete. También podés ejecutar `Instalar.ps1`.

## Límites conocidos

- Un `.xlsx` grande puede producir un `.md` enorme. Revisá los avisos de tamaño y el índice antes de usarlo como contexto de una IA.
- Los PDF escaneados, diagramas, gráficos y hojas Excel complejas pueden perder información al convertirse a texto.
- Procesamiento local, sin activar plugins OCR con IA ni servicios remotos. Algunos formatos podrían intentar acceder a referencias externas según el comportamiento de la biblioteca; evitá documentos no confiables o con vínculos externos si necesitás aislamiento estricto de red.
- La interfaz usa Windows Forms a través de **Windows PowerShell 5.1** y Windows 10/11.
- Si dos carpetas distintas contienen `Informe.docx`, ambas quedan diferenciadas por la ruta. Si `Informe.docx` e `Informe_docx.md` están en el mismo directorio, se informa un conflicto de nombre de salida para evitar sobrescrituras. Si un nombre ya contiene sufijos similares, la herramienta genera `nombre_ext.md` sin reemplazar el original.
- El asistente usa listas separadas por coma para nombres de carpetas y patrones. El árbol permite seleccionar rutas concretas; carpetas muy numerosas se cargan por niveles.

## Desinstalar opción del menú

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File .\Desinstalar-menu.ps1
```

Esto quita el clic derecho; **no elimina** tu configuración, evidencias ni archivos de salida.

## Prueba recomendada

Primero elegí una **carpeta de prueba con 2–3 archivos** (un DOCX, un XLSX y un PDF) y una subcarpeta excluida. Revisá resultados, volvé a ejecutar sin modificar nada, y verificá que los tres queden como `Sin cambios`. Luego usalo con `evidencias`.
