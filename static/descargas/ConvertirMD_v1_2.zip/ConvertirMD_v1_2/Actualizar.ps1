﻿#Requires -Version 5.1
# Actualiza el codigo y el menu sin reinstalar Python ni dependencias.
$ErrorActionPreference = 'Stop'
$target = Join-Path $env:LOCALAPPDATA 'ConvertirMD'
$python = Join-Path $target '.venv\Scripts\python.exe'
if (-not (Test-Path -LiteralPath $python)) {
    throw 'ConvertirMD no está instalado. Ejecutá Instalar.ps1 primero.'
}
$source = $PSScriptRoot
$tokens = $null
$parseErrors = $null
[void][System.Management.Automation.Language.Parser]::ParseFile((Join-Path $source 'ConvertirMD-GUI.ps1'), [ref]$tokens, [ref]$parseErrors)
if ($parseErrors.Count -gt 0) {
    $parseErrors | ForEach-Object { Write-Host $_ -ForegroundColor Red }
    throw 'El script gráfico contiene errores de sintaxis. No se actualizó.'
}
foreach ($name in @('convertir_md.py','ConvertirMD-GUI.ps1')) {
    Copy-Item -LiteralPath (Join-Path $source $name) -Destination (Join-Path $target $name) -Force
}
& $python -m py_compile (Join-Path $target 'convertir_md.py')
if ($LASTEXITCODE -ne 0) { throw 'La prueba de sintaxis del motor Python falló.' }
$psExe = Join-Path $env:SystemRoot 'System32\WindowsPowerShell\v1.0\powershell.exe'
$gui = Join-Path $target 'ConvertirMD-GUI.ps1'
$regKey = 'HKCU:\Software\Classes\Directory\shell\ConvertirMD'
New-Item -Path ($regKey + '\command') -Force | Out-Null
New-ItemProperty -Path $regKey -Name 'MUIVerb' -Value 'Convertir carpeta a Markdown' -PropertyType String -Force | Out-Null
$cmdFolder = '"' + $psExe + '" -NoProfile -ExecutionPolicy Bypass -STA -WindowStyle Hidden -File "' + $gui + '" -SelectedFolder "%1"'
Set-Item -Path ($regKey + '\command') -Value $cmdFolder
$cmdFile = '"' + $psExe + '" -NoProfile -ExecutionPolicy Bypass -STA -WindowStyle Hidden -File "' + $gui + '" -SelectedFile "%1"'
foreach ($ext in @('.docx','.xlsx','.xls','.pptx','.pdf','.html','.htm','.csv','.txt','.odt')) {
    $fileKey = 'HKCU:\Software\Classes\SystemFileAssociations\' + $ext + '\shell\ConvertirMDFile'
    New-Item -Path ($fileKey + '\command') -Force | Out-Null
    New-ItemProperty -Path $fileKey -Name 'MUIVerb' -Value 'Convertir archivo a Markdown' -PropertyType String -Force | Out-Null
    Set-Item -Path ($fileKey + '\command') -Value $cmdFile
}
Write-Host ''
Write-Host 'ConvertirMD 1.2 actualizado. No fue necesario reinstalar MarkItDown.' -ForegroundColor Green
Write-Host 'Clic derecho: carpeta o archivo compatible > Mostrar más opciones.'
