﻿#Requires -Version 5.1
$regKey = 'HKCU:\Software\Classes\Directory\shell\ConvertirMD'
if (Test-Path $regKey) { Remove-Item -Path $regKey -Recurse -Force }
foreach ($ext in @('.docx','.xlsx','.xls','.pptx','.pdf','.html','.htm','.csv','.txt','.odt')) {
    $key = 'HKCU:\Software\Classes\SystemFileAssociations\' + $ext + '\shell\ConvertirMDFile'
    if (Test-Path $key) { Remove-Item -Path $key -Recurse -Force }
}
Write-Host 'Menú contextual de ConvertirMD eliminado. Los documentos no se modificaron.'
