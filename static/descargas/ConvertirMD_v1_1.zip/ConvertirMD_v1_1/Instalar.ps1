﻿#Requires -Version 5.1
# Ejecutar una sola vez desde Windows PowerShell (no necesita administrador).
$ErrorActionPreference = 'Stop'

Write-Host ''
Write-Host 'ConvertirMD - instalación local' -ForegroundColor Cyan
Write-Host '-----------------------------'
$source = $PSScriptRoot
$target = Join-Path $env:LOCALAPPDATA 'ConvertirMD'
$venv = Join-Path $target '.venv'
$pythonVenv = Join-Path $venv 'Scripts\python.exe'

$pythonExe = $null
$pythonPrefix = @()
if (Get-Command py.exe -ErrorAction SilentlyContinue) {
    $pythonExe = 'py.exe'
    $pythonPrefix = @('-3')
} elseif (Get-Command python.exe -ErrorAction SilentlyContinue) {
    $pythonExe = 'python.exe'
}
if (-not $pythonExe) {
    Write-Host 'Falta Python 3.10 a 3.14.' -ForegroundColor Yellow
    Write-Host 'Instalalo desde https://www.python.org/downloads/windows/ y volvé a ejecutar este instalador.'
    exit 1
}

# Evitar Python -c con cadenas entrecomilladas: Windows PowerShell 5.1
# puede modificar esas comillas al pasar los argumentos a py.exe/python.exe.
$versionText = (& $pythonExe @pythonPrefix --version | Out-String).Trim()
if ($LASTEXITCODE -ne 0 -or $versionText -notmatch '^Python\s+(\d+)\.(\d+)(?:\.\d+)?') {
    Write-Host 'No se pudo detectar correctamente la versión de Python.' -ForegroundColor Red
    Write-Host $versionText
    exit 1
}
$version = [version]("$($Matches[1]).$($Matches[2])")
if ($version -lt [version]'3.10' -or $version -ge [version]'3.15') {
    Write-Host "Python $version no es compatible. Necesitás Python 3.10 a 3.14." -ForegroundColor Red
    exit 1
}
Write-Host "Python $version detectado."

New-Item -ItemType Directory -Path $target -Force | Out-Null
foreach ($name in @('convertir_md.py', 'ConvertirMD-GUI.ps1')) {
    Copy-Item -LiteralPath (Join-Path $source $name) -Destination (Join-Path $target $name) -Force
}
if (-not (Test-Path -LiteralPath $pythonVenv)) {
    Write-Host 'Creando entorno Python independiente...'
    & $pythonExe @pythonPrefix -m venv $venv
    if ($LASTEXITCODE -ne 0) { throw 'No se pudo crear el entorno virtual.' }
}
Write-Host 'Instalando MarkItDown para documentos Office y PDF... (puede tardar varios minutos)'
& $pythonVenv -m pip install --upgrade pip
if ($LASTEXITCODE -ne 0) { throw 'Falló la actualización de pip.' }
& $pythonVenv -m pip install --upgrade 'markitdown[docx,xlsx,xls,pptx,pdf]'
if ($LASTEXITCODE -ne 0) { throw 'Falló la instalación de MarkItDown.' }
& $pythonVenv -c 'from markitdown import MarkItDown'
if ($LASTEXITCODE -ne 0) { throw 'La prueba de MarkItDown falló.' }
Write-Host 'MarkItDown OK.' -ForegroundColor Green

# Menú contextual sólo para el usuario actual (HKCU), sin administrador.
$regKey = 'HKCU:\Software\Classes\Directory\shell\ConvertirMD'
$regCommand = Join-Path $regKey 'command'
New-Item -Path $regKey -Force | Out-Null
New-Item -Path $regCommand -Force | Out-Null
Set-ItemProperty -Path $regKey -Name '(default)' -Value 'Convertir carpeta a Markdown' -ErrorAction SilentlyContinue
New-ItemProperty -Path $regKey -Name 'MUIVerb' -Value 'Convertir carpeta a Markdown' -PropertyType String -Force | Out-Null
New-ItemProperty -Path $regKey -Name 'Icon' -Value (Join-Path $env:SystemRoot 'System32\shell32.dll') -PropertyType String -Force | Out-Null
$psExe = Join-Path $env:SystemRoot 'System32\WindowsPowerShell\v1.0\powershell.exe'
$gui = Join-Path $target 'ConvertirMD-GUI.ps1'
$cmd = '"' + $psExe + '" -NoProfile -ExecutionPolicy Bypass -STA -WindowStyle Hidden -File "' + $gui + '" -SelectedFolder "%1"'
Set-Item -Path $regCommand -Value $cmd

# Menú contextual para archivos individuales compatibles.
$cmdFile = '"' + $psExe + '" -NoProfile -ExecutionPolicy Bypass -STA -WindowStyle Hidden -File "' + $gui + '" -SelectedFile "%1"'
foreach ($ext in @('.docx','.xlsx','.xls','.pptx','.pdf','.html','.htm','.csv','.txt','.odt')) {
    $fileKey = 'HKCU:\Software\Classes\SystemFileAssociations\' + $ext + '\shell\ConvertirMDFile'
    New-Item -Path ($fileKey + '\command') -Force | Out-Null
    New-ItemProperty -Path $fileKey -Name 'MUIVerb' -Value 'Convertir archivo a Markdown' -PropertyType String -Force | Out-Null
    Set-Item -Path ($fileKey + '\command') -Value $cmdFile
}

Write-Host ''
Write-Host 'Instalación completada.' -ForegroundColor Green
Write-Host ('Programa: ' + $target)
Write-Host 'En el Explorador: clic derecho sobre una carpeta o archivo compatible > Mostrar más opciones > Convertir a Markdown'
Write-Host 'Si no hay INI, se abrirá el asistente de configuración.'
Write-Host ''
Read-Host 'Presioná Enter para cerrar' | Out-Null
