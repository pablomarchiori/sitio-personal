﻿#Requires -Version 5.1
param([Parameter(Mandatory=$true)][string]$Ruta)
$gui = Join-Path $env:LOCALAPPDATA 'ConvertirMD\ConvertirMD-GUI.ps1'
if (-not (Test-Path $gui)) { throw 'ConvertirMD no está instalado.' }
if (Test-Path -LiteralPath $Ruta -PathType Leaf) {
    & powershell.exe -NoProfile -ExecutionPolicy Bypass -STA -File $gui -SelectedFile $Ruta
} else {
    & powershell.exe -NoProfile -ExecutionPolicy Bypass -STA -File $gui -SelectedFolder $Ruta
}
